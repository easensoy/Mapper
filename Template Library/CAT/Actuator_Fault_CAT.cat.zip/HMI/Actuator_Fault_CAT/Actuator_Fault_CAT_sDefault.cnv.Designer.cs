/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 2/24/2026
 * Time: 2:25 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace HMI.Main.Symbols.Actuator_Fault_CAT
{
	/// <summary>
	/// Summary description for sDefault.
	/// </summary>
	partial class sDefault
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary2 = new NxtControl.GuiFramework.PropertyDictionary();
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary3 = new NxtControl.GuiFramework.PropertyDictionary();
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary1 = new NxtControl.GuiFramework.PropertyDictionary();
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary4 = new NxtControl.GuiFramework.PropertyDictionary();
			this.drawnButton1 = new NxtControl.GuiFramework.DrawnButton();
			this.fault_active = new System.HMI.Symbols.Base.Led<bool>();
			this.fault_code = new System.HMI.Symbols.Base.Label<short>();
			this.drawnButton2 = new NxtControl.GuiFramework.DrawnButton();
			this.drawnButton3 = new NxtControl.GuiFramework.DrawnButton();
			// 
			// drawnButton1
			// 
			this.drawnButton1.Bounds = new NxtControl.Drawing.RectF(((float)(48D)), ((float)(32D)), ((float)(136D)), ((float)(48D)));
			this.drawnButton1.Brush = new NxtControl.Drawing.Brush("ButtonBrush");
			this.drawnButton1.Font = new NxtControl.Drawing.Font("ButtonFont");
			this.drawnButton1.InnerBorderColor = new NxtControl.Drawing.Color("ButtonInnerBorderColor");
			this.drawnButton1.Name = "drawnButton1";
			this.drawnButton1.Pen = new NxtControl.Drawing.Pen("ButtonPen");
			this.drawnButton1.Radius = 4D;
			this.drawnButton1.Text = "CMD_WORK";
			this.drawnButton1.TextColor = new NxtControl.Drawing.Color("ButtonTextColor");
			this.drawnButton1.TextColorMouseDown = new NxtControl.Drawing.Color("ButtonTextColorMouseDown");
			this.drawnButton1.Use3DEffect = false;
			this.drawnButton1.Click += new System.EventHandler(this.CMD_WORK);
			// 
			// fault_active
			// 
			this.fault_active.BeginInit();
			this.fault_active.ColorFrame = new NxtControl.Drawing.Color("LedFrameColor");
			this.fault_active.DesignMatrix = new NxtControl.Drawing.Matrix2D(3.333333333333333D, 0D, 0D, 3.3333333333333344D, 372D, 100D);
			this.fault_active.FrameSize = 33F;
			this.fault_active.IsOnlyInput = true;
			this.fault_active.Name = "fault_active";
			propertyDictionary2.Add("Color", new NxtControl.Drawing.Color("LedFalseColor"));
			propertyDictionary3.Add("Color", new NxtControl.Drawing.Color("LedTrueColor"));
			this.fault_active.Ranges.Clear();
			this.fault_active.Ranges.Add(new NxtControl.GuiFramework.Range<bool>(false, propertyDictionary2));
			this.fault_active.Ranges.Add(new NxtControl.GuiFramework.Range<bool>(true, propertyDictionary3));
			propertyDictionary1.Add("Color", new NxtControl.Drawing.Color("LedFalseColor"));
			this.fault_active.Ranges.DefaultPropertyValues = propertyDictionary1;
			this.fault_active.TagName = "fault_active";
			this.fault_active.EndInit();
			// 
			// fault_code
			// 
			this.fault_code.BeginInit();
			this.fault_code.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.fault_code.DecimalPlacesCount = ((uint)(2u));
			this.fault_code.DesignMatrix = new NxtControl.Drawing.Matrix2D(1.1199999999999999D, 0D, 0D, 1.9047619047619047D, 288D, 160D);
			this.fault_code.FontScale = false;
			this.fault_code.IsOnlyInput = true;
			this.fault_code.LeadingZeros = ((uint)(0u));
			this.fault_code.Name = "fault_code";
			this.fault_code.NumberBase = NxtControl.GuiFramework.NumberBase.Decimal;
			propertyDictionary4.Add("Text", "${Value}");
			propertyDictionary4.Add("TextColor", new NxtControl.Drawing.Color("LabelTextColor"));
			propertyDictionary4.Add("Brush", new NxtControl.Drawing.Brush("LabelBrush"));
			propertyDictionary4.Add("Pen", new NxtControl.Drawing.Pen("LabelPen"));
			this.fault_code.Ranges.DefaultPropertyValues = propertyDictionary4;
			this.fault_code.TagName = "fault_code";
			this.fault_code.EndInit();
			// 
			// drawnButton2
			// 
			this.drawnButton2.Bounds = new NxtControl.Drawing.RectF(((float)(48D)), ((float)(136D)), ((float)(136D)), ((float)(56D)));
			this.drawnButton2.Brush = new NxtControl.Drawing.Brush("ButtonBrush");
			this.drawnButton2.Font = new NxtControl.Drawing.Font("ButtonFont");
			this.drawnButton2.InnerBorderColor = new NxtControl.Drawing.Color("ButtonInnerBorderColor");
			this.drawnButton2.Name = "drawnButton2";
			this.drawnButton2.Pen = new NxtControl.Drawing.Pen("ButtonPen");
			this.drawnButton2.Radius = 4D;
			this.drawnButton2.Text = "CMD_HOME";
			this.drawnButton2.TextColor = new NxtControl.Drawing.Color("ButtonTextColor");
			this.drawnButton2.TextColorMouseDown = new NxtControl.Drawing.Color("ButtonTextColorMouseDown");
			this.drawnButton2.Use3DEffect = false;
			this.drawnButton2.Click += new System.EventHandler(this.CMD_HOME);
			// 
			// drawnButton3
			// 
			this.drawnButton3.Bounds = new NxtControl.Drawing.RectF(((float)(48D)), ((float)(256D)), ((float)(136D)), ((float)(48D)));
			this.drawnButton3.Brush = new NxtControl.Drawing.Brush("ButtonBrush");
			this.drawnButton3.Font = new NxtControl.Drawing.Font("ButtonFont");
			this.drawnButton3.InnerBorderColor = new NxtControl.Drawing.Color("ButtonInnerBorderColor");
			this.drawnButton3.Name = "drawnButton3";
			this.drawnButton3.Pen = new NxtControl.Drawing.Pen("ButtonPen");
			this.drawnButton3.Radius = 4D;
			this.drawnButton3.Text = "RESET";
			this.drawnButton3.TextColor = new NxtControl.Drawing.Color("ButtonTextColor");
			this.drawnButton3.TextColorMouseDown = new NxtControl.Drawing.Color("ButtonTextColorMouseDown");
			this.drawnButton3.Use3DEffect = false;
			this.drawnButton3.Click += new System.EventHandler(this.RESET);
			// 
			// sDefault
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.drawnButton1,
			this.fault_active,
			this.fault_code,
			this.drawnButton2,
			this.drawnButton3});
			this.SymbolSize = new System.Drawing.Size(600, 400);

		}
		private NxtControl.GuiFramework.DrawnButton drawnButton3;
		private NxtControl.GuiFramework.DrawnButton drawnButton2;
		private NxtControl.GuiFramework.DrawnButton drawnButton1;
		private System.HMI.Symbols.Base.Led<bool> fault_active;
		private System.HMI.Symbols.Base.Label<short> fault_code;
		#endregion
	}
}
