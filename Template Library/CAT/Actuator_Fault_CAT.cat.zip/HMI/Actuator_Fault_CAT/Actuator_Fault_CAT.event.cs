/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 2/24/2026
 * Time: 2:25 PM
 * 
 */
using System;
using NxtControl.GuiFramework;
using NxtControl.Services;

#region Definitions;
#region #Actuator_Fault_CAT_HMI;

namespace HMI.Main.Symbols.Actuator_Fault_CAT
{

  public class CMD_WORKEventArgs : System.EventArgs
  {
    public CMD_WORKEventArgs()
    {
    }

  }

  public class CMD_HOMEEventArgs : System.EventArgs
  {
    public CMD_HOMEEventArgs()
    {
    }

  }

  public class RESETEventArgs : System.EventArgs
  {
    public RESETEventArgs()
    {
    }

  }

}

namespace HMI.Main.Symbols.Actuator_Fault_CAT
{
  partial class sDefault
  {
    public bool FireEvent_CMD_WORK()
    {
      return ((IHMIAccessorOutput)this).FireEvent(0, new object[] {});
    }
    public bool FireEvent_CMD_WORK(HMI.Main.Symbols.Actuator_Fault_CAT.CMD_WORKEventArgs ea)
    {
      object[] _values_ = new object[0];
      return ((IHMIAccessorOutput)this).FireEvent(0, _values_);
    }
    public bool FireEvent_CMD_HOME()
    {
      return ((IHMIAccessorOutput)this).FireEvent(1, new object[] {});
    }
    public bool FireEvent_CMD_HOME(HMI.Main.Symbols.Actuator_Fault_CAT.CMD_HOMEEventArgs ea)
    {
      object[] _values_ = new object[0];
      return ((IHMIAccessorOutput)this).FireEvent(1, _values_);
    }
    public bool FireEvent_RESET()
    {
      return ((IHMIAccessorOutput)this).FireEvent(2, new object[] {});
    }
    public bool FireEvent_RESET(HMI.Main.Symbols.Actuator_Fault_CAT.RESETEventArgs ea)
    {
      object[] _values_ = new object[0];
      return ((IHMIAccessorOutput)this).FireEvent(2, _values_);
    }

  }
}
#endregion #Actuator_Fault_CAT_HMI;

#endregion Definitions;
