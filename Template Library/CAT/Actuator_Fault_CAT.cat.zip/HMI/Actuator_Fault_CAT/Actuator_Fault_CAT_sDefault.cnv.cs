/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 2/24/2026
 * Time: 2:25 PM
 * 
 */

using System;
using NxtControl.GuiFramework;

namespace HMI.Main.Symbols.Actuator_Fault_CAT
{
	/// <summary>
	/// Description of sDefault.
	/// </summary>
	public partial class sDefault : NxtControl.GuiFramework.HMISymbol
	{
		public sDefault()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
		}

		void RoundedRectangle1Click(object sender, EventArgs e)
		{
			// TODO: Implement RoundedRectangle1Click
		}

		void DrawnButton3Click(object sender, EventArgs e)
		{
			// TODO: Implement DrawnButton3Click
		}

		void CMD_WORK(object sender, EventArgs e)
		{
			// TODO: Implement CMD_WORK
		}

		void CMD_HOME(object sender, EventArgs e)
		{
			// TODO: Implement CMD_HOME
		}

		void RESET(object sender, EventArgs e)
		{
			// TODO: Implement RESET
		}
	}
}
