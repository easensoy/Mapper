/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 2/2/2026
 * Time: 4:04 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace HMI.Main.Symbols.Sensor_Bool_CAT
{
	/// <summary>
	/// Summary description for sDefault.
	/// </summary>
	partial class sDefault
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary2 = new NxtControl.GuiFramework.PropertyDictionary();
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary3 = new NxtControl.GuiFramework.PropertyDictionary();
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary1 = new NxtControl.GuiFramework.PropertyDictionary();
			this.State = new System.HMI.Symbols.Base.Led<bool>();
			// 
			// State
			// 
			this.State.BeginInit();
			this.State.ColorFrame = new NxtControl.Drawing.Color("LedFrameColor");
			this.State.DesignMatrix = new NxtControl.Drawing.Matrix2D(3D, 0D, 0D, 3D, 26D, 26D);
			this.State.FrameSize = 33F;
			this.State.IsOnlyInput = true;
			this.State.Name = "State";
			propertyDictionary2.Add("Color", new NxtControl.Drawing.Color("LedFalseColor"));
			propertyDictionary3.Add("Color", new NxtControl.Drawing.Color("LedTrueColor"));
			this.State.Ranges.Clear();
			this.State.Ranges.Add(new NxtControl.GuiFramework.Range<bool>(false, propertyDictionary2));
			this.State.Ranges.Add(new NxtControl.GuiFramework.Range<bool>(true, propertyDictionary3));
			propertyDictionary1.Add("Color", new NxtControl.Drawing.Color("LedFalseColor"));
			this.State.Ranges.DefaultPropertyValues = propertyDictionary1;
			this.State.TagName = "State";
			this.State.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.StateValueChanged);
			this.State.EndInit();
			// 
			// sDefault
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.State});
			this.SymbolSize = new System.Drawing.Size(600, 400);

		}
		private System.HMI.Symbols.Base.Led<bool> State;
		#endregion
	}
}
