using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region Five_State_Actuator_CAT_HMI;
#endregion Five_State_Actuator_CAT_HMI;

#endregion Definitions;

