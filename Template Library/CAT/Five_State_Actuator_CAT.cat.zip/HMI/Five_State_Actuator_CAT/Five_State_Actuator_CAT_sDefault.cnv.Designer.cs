/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 10/7/2025
 * Time: 10:13 AM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace HMI.Main.Symbols.Five_State_Actuator_CAT
{
	/// <summary>
	/// Summary description for sDefault.
	/// </summary>
	partial class sDefault
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary2 = new NxtControl.GuiFramework.PropertyDictionary();
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary3 = new NxtControl.GuiFramework.PropertyDictionary();
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary4 = new NxtControl.GuiFramework.PropertyDictionary();
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary5 = new NxtControl.GuiFramework.PropertyDictionary();
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary6 = new NxtControl.GuiFramework.PropertyDictionary();
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary1 = new NxtControl.GuiFramework.PropertyDictionary();
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary8 = new NxtControl.GuiFramework.PropertyDictionary();
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary9 = new NxtControl.GuiFramework.PropertyDictionary();
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary7 = new NxtControl.GuiFramework.PropertyDictionary();
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary11 = new NxtControl.GuiFramework.PropertyDictionary();
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary12 = new NxtControl.GuiFramework.PropertyDictionary();
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary10 = new NxtControl.GuiFramework.PropertyDictionary();
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary14 = new NxtControl.GuiFramework.PropertyDictionary();
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary15 = new NxtControl.GuiFramework.PropertyDictionary();
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary13 = new NxtControl.GuiFramework.PropertyDictionary();
			this.current_state_to_process = new System.HMI.Symbols.Base.FreeText<short>();
			this.rectangle1 = new NxtControl.GuiFramework.Rectangle();
			this.current_state_to_plc = new System.HMI.Symbols.Base.Led<bool>();
			this.atHome = new System.HMI.Symbols.Base.Led<bool>();
			this.atWork = new System.HMI.Symbols.Base.Led<bool>();
			this.freeText1 = new NxtControl.GuiFramework.FreeText();
			this.freeText2 = new NxtControl.GuiFramework.FreeText();
			this.freeText3 = new NxtControl.GuiFramework.FreeText();
			// 
			// current_state_to_process
			// 
			this.current_state_to_process.BeginInit();
			this.current_state_to_process.DecimalPlacesCount = ((uint)(2u));
			this.current_state_to_process.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 69D, 8D);
			this.current_state_to_process.Font = new NxtControl.Drawing.Font("BigCanvasTopologyButtonFont");
			this.current_state_to_process.IsOnlyInput = true;
			this.current_state_to_process.Name = "current_state_to_process";
			propertyDictionary2.Add("Text", "At Home Initial");
			propertyDictionary2.Add("TextColor", new NxtControl.Drawing.Color(((byte)(0)), ((byte)(0)), ((byte)(0))));
			propertyDictionary3.Add("Text", "Moving To Work");
			propertyDictionary3.Add("TextColor", new NxtControl.Drawing.Color(((byte)(178)), ((byte)(14)), ((byte)(18))));
			propertyDictionary4.Add("Text", "   At Work");
			propertyDictionary4.Add("TextColor", new NxtControl.Drawing.Color(((byte)(26)), ((byte)(170)), ((byte)(66))));
			propertyDictionary5.Add("Text", "Moving To Home");
			propertyDictionary5.Add("TextColor", new NxtControl.Drawing.Color(((byte)(178)), ((byte)(14)), ((byte)(18))));
			propertyDictionary6.Add("Text", "  At Home End");
			propertyDictionary6.Add("TextColor", new NxtControl.Drawing.Color(((byte)(26)), ((byte)(170)), ((byte)(66))));
			this.current_state_to_process.Ranges.Clear();
			this.current_state_to_process.Ranges.Add(new NxtControl.GuiFramework.Range<short>(((short)(0)), propertyDictionary2));
			this.current_state_to_process.Ranges.Add(new NxtControl.GuiFramework.Range<short>(((short)(1)), propertyDictionary3));
			this.current_state_to_process.Ranges.Add(new NxtControl.GuiFramework.Range<short>(((short)(2)), propertyDictionary4));
			this.current_state_to_process.Ranges.Add(new NxtControl.GuiFramework.Range<short>(((short)(3)), propertyDictionary5));
			this.current_state_to_process.Ranges.Add(new NxtControl.GuiFramework.Range<short>(((short)(4)), propertyDictionary6));
			propertyDictionary1.Add("Text", "${Value}");
			propertyDictionary1.Add("TextColor", new NxtControl.Drawing.Color("AlarmControlForeCellColor"));
			this.current_state_to_process.Ranges.DefaultPropertyValues = propertyDictionary1;
			this.current_state_to_process.TagName = "current_state_to_process";
			this.current_state_to_process.TextAngle = 0F;
			this.current_state_to_process.EndInit();
			// 
			// rectangle1
			// 
			this.rectangle1.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(300D)), ((float)(40D)));
			this.rectangle1.Font = new NxtControl.Drawing.Font("HMI Sans Serif", 9F, System.Drawing.FontStyle.Regular);
			this.rectangle1.Name = "rectangle1";
			// 
			// current_state_to_plc
			// 
			this.current_state_to_plc.BeginInit();
			this.current_state_to_plc.ColorFrame = new NxtControl.Drawing.Color("LedFrameColor");
			this.current_state_to_plc.DesignMatrix = new NxtControl.Drawing.Matrix2D(2D, 0D, 0D, 2D, 124D, 56D);
			this.current_state_to_plc.FrameSize = 33F;
			this.current_state_to_plc.IsOnlyInput = true;
			this.current_state_to_plc.Name = "current_state_to_plc";
			propertyDictionary8.Add("Color", new NxtControl.Drawing.Color("LedFalseColor"));
			propertyDictionary9.Add("Color", new NxtControl.Drawing.Color("LedTrueColor"));
			this.current_state_to_plc.Ranges.Clear();
			this.current_state_to_plc.Ranges.Add(new NxtControl.GuiFramework.Range<bool>(false, propertyDictionary8));
			this.current_state_to_plc.Ranges.Add(new NxtControl.GuiFramework.Range<bool>(true, propertyDictionary9));
			propertyDictionary7.Add("Color", new NxtControl.Drawing.Color("LedFalseColor"));
			this.current_state_to_plc.Ranges.DefaultPropertyValues = propertyDictionary7;
			this.current_state_to_plc.TagName = "current_state_to_plc";
			this.current_state_to_plc.EndInit();
			// 
			// atHome
			// 
			this.atHome.BeginInit();
			this.atHome.ColorFrame = new NxtControl.Drawing.Color("LedFrameColor");
			this.atHome.DesignMatrix = new NxtControl.Drawing.Matrix2D(2D, 0D, 0D, 2D, 268D, 56D);
			this.atHome.FrameSize = 33F;
			this.atHome.IsOnlyInput = true;
			this.atHome.Name = "atHome";
			propertyDictionary11.Add("Color", new NxtControl.Drawing.Color("LedFalseColor"));
			propertyDictionary12.Add("Color", new NxtControl.Drawing.Color("LedTrueColor"));
			this.atHome.Ranges.Clear();
			this.atHome.Ranges.Add(new NxtControl.GuiFramework.Range<bool>(false, propertyDictionary11));
			this.atHome.Ranges.Add(new NxtControl.GuiFramework.Range<bool>(true, propertyDictionary12));
			propertyDictionary10.Add("Color", new NxtControl.Drawing.Color("LedFalseColor"));
			this.atHome.Ranges.DefaultPropertyValues = propertyDictionary10;
			this.atHome.TagName = "atHome";
			this.atHome.EndInit();
			// 
			// atWork
			// 
			this.atWork.BeginInit();
			this.atWork.ColorFrame = new NxtControl.Drawing.Color("LedFrameColor");
			this.atWork.DesignMatrix = new NxtControl.Drawing.Matrix2D(2D, 0D, 0D, 2D, 268D, 84D);
			this.atWork.FrameSize = 33F;
			this.atWork.IsOnlyInput = true;
			this.atWork.Name = "atWork";
			propertyDictionary14.Add("Color", new NxtControl.Drawing.Color("LedFalseColor"));
			propertyDictionary15.Add("Color", new NxtControl.Drawing.Color("LedTrueColor"));
			this.atWork.Ranges.Clear();
			this.atWork.Ranges.Add(new NxtControl.GuiFramework.Range<bool>(false, propertyDictionary14));
			this.atWork.Ranges.Add(new NxtControl.GuiFramework.Range<bool>(true, propertyDictionary15));
			propertyDictionary13.Add("Color", new NxtControl.Drawing.Color("LedFalseColor"));
			this.atWork.Ranges.DefaultPropertyValues = propertyDictionary13;
			this.atWork.TagName = "atWork";
			this.atWork.EndInit();
			// 
			// freeText1
			// 
			this.freeText1.Color = new NxtControl.Drawing.Color(((byte)(0)), ((byte)(0)), ((byte)(0)));
			this.freeText1.Font = new NxtControl.Drawing.Font("BigCanvasTopologyButtonFont");
			this.freeText1.Location = new NxtControl.Drawing.PointF(16D, 42D);
			this.freeText1.Name = "freeText1";
			this.freeText1.Text = "To Work";
			// 
			// freeText2
			// 
			this.freeText2.Color = new NxtControl.Drawing.Color(((byte)(0)), ((byte)(0)), ((byte)(0)));
			this.freeText2.Font = new NxtControl.Drawing.Font("BigCanvasTopologyButtonFont");
			this.freeText2.Location = new NxtControl.Drawing.PointF(156D, 42D);
			this.freeText2.Name = "freeText2";
			this.freeText2.Text = "At Home";
			// 
			// freeText3
			// 
			this.freeText3.Color = new NxtControl.Drawing.Color(((byte)(0)), ((byte)(0)), ((byte)(0)));
			this.freeText3.Font = new NxtControl.Drawing.Font("BigCanvasTopologyButtonFont");
			this.freeText3.Location = new NxtControl.Drawing.PointF(156D, 71D);
			this.freeText3.Name = "freeText3";
			this.freeText3.Text = "At Work";
			// 
			// sDefault
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.rectangle1,
			this.current_state_to_process,
			this.current_state_to_plc,
			this.atHome,
			this.atWork,
			this.freeText1,
			this.freeText2,
			this.freeText3});
			this.SymbolSize = new System.Drawing.Size(300, 100);

		}
		private System.HMI.Symbols.Base.FreeText<short> current_state_to_process;
		private NxtControl.GuiFramework.Rectangle rectangle1;
		private System.HMI.Symbols.Base.Led<bool> current_state_to_plc;
		private System.HMI.Symbols.Base.Led<bool> atHome;
		private System.HMI.Symbols.Base.Led<bool> atWork;
		private NxtControl.GuiFramework.FreeText freeText1;
		private NxtControl.GuiFramework.FreeText freeText2;
		private NxtControl.GuiFramework.FreeText freeText3;
		#endregion
	}
}
