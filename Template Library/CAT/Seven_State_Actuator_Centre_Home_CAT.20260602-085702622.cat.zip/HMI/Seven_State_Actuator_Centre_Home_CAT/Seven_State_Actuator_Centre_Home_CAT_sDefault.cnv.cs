/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 10/7/2025
 * Time: 10:13 AM
 * 
 */

using System;
using NxtControl.GuiFramework;

namespace HMI.Main.Symbols.Seven_State_Actuator_Centre_Home_CAT
{
	/// <summary>
	/// Description of sDefault.
	/// </summary>
	public partial class sDefault : NxtControl.GuiFramework.HMISymbol
	{
		public sDefault()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			FAULT_EVENT_Fired += FaultStatusChanged;
			mode_event_Fired += ModeChanged;
			
		}
		
		void FaultStatusChanged(object sender, FAULT_EVENTEventArgs e)
		{
			if(e.fault_active.Value == true)
			{
				fault_code.Visible = true;
			}		
			else
			{
				fault_code.Visible = false;
			}
		
		}

		void ToWork1ButtonClick(object sender, EventArgs e)
		{
			// TODO: Implement DrawnButton1Click
			FireEvent_cmd_event(true,false,false);
		}
		
		void ToWork2ButtonClick(object sender, EventArgs e)
		{
			// TODO: Implement DrawnButton1Click
			FireEvent_cmd_event(false,false,true);
		}
		
		void ToHomeButtonClick(object sender, EventArgs e)
		{
			// TODO: Implement DrawnButton1Click
			FireEvent_cmd_event(false,true,false);
		}
		
		void ToWork1ButtonVisibility(Boolean show)
		{
			ToWork1Button.Visible = show;
		}
		
		void ToWork2ButtonVisibility(Boolean show)
		{
			ToWork2Button.Visible = show;
		}
		
		void ToHomeButtonVisibility(Boolean show)
		{
			ToHomeButton.Visible = show;
		}
		
		void ModeChanged(object sender, mode_eventEventArgs e)
		{
			if(e.ModeCMD.Value == 3)
			{
				ToWork1ButtonVisibility(true);
				ToWork2ButtonVisibility(true);
				ToHomeButtonVisibility(true);
			}
			else
			{	
				ToWork1ButtonVisibility(false);
				ToWork2ButtonVisibility(false);
				ToHomeButtonVisibility(false);
			}
		}
	}
}
