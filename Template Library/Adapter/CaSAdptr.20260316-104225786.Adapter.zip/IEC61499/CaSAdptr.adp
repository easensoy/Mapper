<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE AdapterType SYSTEM "../LibraryElement.dtd">
<AdapterType GUID="731a3dcd-69b2-42d3-92a4-494f3f392162" Name="CaSAdptr" Comment="Adapter Interface" Namespace="Main">
  <Identification Standard="61499-1" />
  <VersionInfo Organization="Schneider Electric" Version="0.0" Author="Evans_A" Date="7/10/2025" />
  <InterfaceList>
    <EventInputs>
      <Event Name="LLF" Comment="lower level Fault Event">
        <With Var="LL_Fault" />
      </Event>
      <Event Name="LLM">
        <With Var="LL_Mode" />
      </Event>
      <Event Name="LLCT">
        <With Var="LL_CycleType" />
      </Event>
    </EventInputs>
    <EventOutputs>
      <Event Name="INIT">
        <With Var="ParentName" />
      </Event>
      <Event Name="MCTRL" Comment="Confirmation from Plug">
        <With Var="ModeCMD" />
      </Event>
      <Event Name="CTCTRL">
        <With Var="CycleTypeCMD" />
      </Event>
      <Event Name="FRCTRL">
        <With Var="FaultResetCMD" />
      </Event>
    </EventOutputs>
    <InputVars>
      <VarDeclaration Name="LL_Fault" Type="BOOL" Comment="Lower Level Fault" />
      <VarDeclaration Name="LL_Mode" Type="INT" />
      <VarDeclaration Name="LL_CycleType" Type="INT" />
    </InputVars>
    <OutputVars>
      <VarDeclaration Name="ModeCMD" Type="INT" Comment="Confirmation Data from Plug" />
      <VarDeclaration Name="CycleTypeCMD" Type="INT" Comment="Indication Data from Plug" />
      <VarDeclaration Name="ParentName" Type="STRING" />
      <VarDeclaration Name="FaultResetCMD" Type="BOOL" />
    </OutputVars>
  </InterfaceList>
  <Service RightInterface="PLUG" LeftInterface="SOCKET">
    <ServiceSequence Name="request_confirm">
      <ServiceTransaction>
        <InputPrimitive Interface="SOCKET" Event="MFBK" Parameters="ModeSTS_0" />
        <OutputPrimitive Interface="PLUG" Event="MFBK" Parameters="ModeSTS_0" />
      </ServiceTransaction>
      <ServiceTransaction>
        <InputPrimitive Interface="PLUG" Event="MCTRL" Parameters="ModeCMD" />
        <OutputPrimitive Interface="SOCKET" Event="MCTRL" Parameters="ModeCMD" />
      </ServiceTransaction>
    </ServiceSequence>
    <ServiceSequence Name="indication_response">
      <ServiceTransaction>
        <InputPrimitive Interface="PLUG" Event="IND" Parameters="CycleTypeCMD" />
        <OutputPrimitive Interface="SOCKET" Event="IND" Parameters="CycleTypeCMD" />
      </ServiceTransaction>
      <ServiceTransaction>
        <InputPrimitive Interface="SOCKET" Event="RSP" Parameters="CycleTypeSTS_0" />
        <OutputPrimitive Interface="PLUG" Event="RSP" Parameters="CycleTypeSTS_0" />
      </ServiceTransaction>
    </ServiceSequence>
  </Service>
</AdapterType>