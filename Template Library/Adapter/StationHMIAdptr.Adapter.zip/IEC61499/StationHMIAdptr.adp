<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE AdapterType SYSTEM "../LibraryElement.dtd">
<AdapterType GUID="6b6c5ac2-fda1-42c7-9b1f-8102fa2fbd7a" Name="StationHMIAdptr" Comment="Adapter Interface" Namespace="Main">
  <Identification Standard="61499-1" />
  <VersionInfo Organization="Schneider Electric" Version="0.0" Author="Evans_A" Date="8/14/2025" />
  <InterfaceList>
    <EventInputs>
      <Event Name="SREQ" Comment="Request from Socket">
        <With Var="StationName" />
        <With Var="ParentName" />
      </Event>
      <Event Name="LMFREQ">
        <With Var="LocalMode" />
      </Event>
      <Event Name="LCTREQ">
        <With Var="LocalCycleType" />
      </Event>
      <Event Name="LLFREQ">
        <With Var="LLFault" />
      </Event>
      <Event Name="LLMREQ">
        <With Var="LLMode" />
      </Event>
      <Event Name="LLCTREQ">
        <With Var="LLCycleType" />
      </Event>
    </EventInputs>
    <EventOutputs>
      <Event Name="MCNF" Comment="Confirmation from Plug">
        <With Var="Mode" />
      </Event>
      <Event Name="CTCNF">
        <With Var="CycleType" />
      </Event>
      <Event Name="FRCNF">
        <With Var="FaultReset" />
      </Event>
    </EventOutputs>
    <InputVars>
      <VarDeclaration Name="StationName" Type="STRING" />
      <VarDeclaration Name="ParentName" Type="STRING" />
      <VarDeclaration Name="LocalMode" Type="INT" />
      <VarDeclaration Name="LocalCycleType" Type="INT" />
      <VarDeclaration Name="LLFault" Type="BOOL" />
      <VarDeclaration Name="LLMode" Type="INT" />
      <VarDeclaration Name="LLCycleType" Type="INT" />
    </InputVars>
    <OutputVars>
      <VarDeclaration Name="Mode" Type="INT" />
      <VarDeclaration Name="CycleType" Type="INT" />
      <VarDeclaration Name="FaultReset" Type="BOOL" />
    </OutputVars>
  </InterfaceList>
  <Service RightInterface="PLUG" LeftInterface="SOCKET">
    <ServiceSequence Name="request_confirm">
      <ServiceTransaction>
        <InputPrimitive Interface="SOCKET" Event="SREQ" Parameters="REQD" />
        <OutputPrimitive Interface="PLUG" Event="SREQ" Parameters="REQD" />
      </ServiceTransaction>
      <ServiceTransaction>
        <InputPrimitive Interface="PLUG" Event="MCNF" Parameters="CNFD" />
        <OutputPrimitive Interface="SOCKET" Event="MCNF" Parameters="CNFD" />
      </ServiceTransaction>
    </ServiceSequence>
    <ServiceSequence Name="indication_response">
      <ServiceTransaction>
        <InputPrimitive Interface="PLUG" Event="CTCNF" Parameters="INDD" />
        <OutputPrimitive Interface="SOCKET" Event="CTCNF" Parameters="INDD" />
      </ServiceTransaction>
      <ServiceTransaction>
        <InputPrimitive Interface="SOCKET" Event="PNREQ" Parameters="RSPD" />
        <OutputPrimitive Interface="PLUG" Event="PNREQ" Parameters="RSPD" />
      </ServiceTransaction>
    </ServiceSequence>
  </Service>
</AdapterType>