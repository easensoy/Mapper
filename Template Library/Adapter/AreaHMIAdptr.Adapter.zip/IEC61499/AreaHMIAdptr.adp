<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE AdapterType SYSTEM "../LibraryElement.dtd">
<AdapterType GUID="27fdc301-5994-45a9-944c-732fb2f8531b" Name="AreaHMIAdptr" Comment="Adapter Interface" Namespace="Main">
  <Identification Standard="61499-1" />
  <VersionInfo Organization="Schneider Electric" Version="0.0" Author="Evans_A" Date="8/14/2025" />
  <InterfaceList>
    <EventInputs>
      <Event Name="SMREQ" Comment="Request from Socket">
        <With Var="SystemMode" />
      </Event>
      <Event Name="SCTREQ">
        <With Var="SystemCycleType" />
      </Event>
      <Event Name="LLFREQ">
        <With Var="LL_FaultStatus" />
      </Event>
      <Event Name="ANREQ">
        <With Var="AreaName" />
      </Event>
    </EventInputs>
    <EventOutputs>
      <Event Name="MCNF" Comment="Confirmation from Plug">
        <With Var="Mode" />
      </Event>
      <Event Name="CTCNF">
        <With Var="CycleType" />
      </Event>
      <Event Name="FRCNF">
        <With Var="FaultReset" />
      </Event>
    </EventOutputs>
    <InputVars>
      <VarDeclaration Name="SystemMode" Type="INT" />
      <VarDeclaration Name="SystemCycleType" Type="INT" />
      <VarDeclaration Name="LL_FaultStatus" Type="BOOL" />
      <VarDeclaration Name="AreaName" Type="STRING" />
    </InputVars>
    <OutputVars>
      <VarDeclaration Name="Mode" Type="INT" />
      <VarDeclaration Name="CycleType" Type="INT" />
      <VarDeclaration Name="FaultReset" Type="BOOL" />
    </OutputVars>
  </InterfaceList>
  <Service RightInterface="PLUG" LeftInterface="SOCKET">
    <ServiceSequence Name="request_confirm">
      <ServiceTransaction>
        <InputPrimitive Interface="SOCKET" Event="SMREQ" Parameters="REQD" />
        <OutputPrimitive Interface="PLUG" Event="SMREQ" Parameters="REQD" />
      </ServiceTransaction>
      <ServiceTransaction>
        <InputPrimitive Interface="PLUG" Event="MCNF" Parameters="CNFD" />
        <OutputPrimitive Interface="SOCKET" Event="MCNF" Parameters="CNFD" />
      </ServiceTransaction>
    </ServiceSequence>
    <ServiceSequence Name="indication_response">
      <ServiceTransaction>
        <InputPrimitive Interface="PLUG" Event="CTCNF" Parameters="INDD" />
        <OutputPrimitive Interface="SOCKET" Event="CTCNF" Parameters="INDD" />
      </ServiceTransaction>
      <ServiceTransaction>
        <InputPrimitive Interface="SOCKET" Event="SCTREQ" Parameters="RSPD" />
        <OutputPrimitive Interface="PLUG" Event="SCTREQ" Parameters="RSPD" />
      </ServiceTransaction>
    </ServiceSequence>
  </Service>
</AdapterType>